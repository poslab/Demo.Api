﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Services.Model
{
    public class Company
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Repository.Model
{
    public class Company
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
    }
}

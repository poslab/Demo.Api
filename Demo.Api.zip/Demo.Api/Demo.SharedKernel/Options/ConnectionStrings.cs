﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.SharedKernel.Options
{
    public class ConnectionStrings
    {
        public string DemoDB { get; set; }
    }
}
